# Geometric Commitment Signatures Paper Package

This package contains a compile-ready LaTeX source bundle for:

`Geometric Commitment Signatures as Detectors of Memorization and Backdoors in Transformer Language Models`

## Contents

- `geometric_commitment_signatures_paper.tex`: main LaTeX source.
- `geometric_commitment_signatures_paper.md`: Markdown source/reference copy.
- `figures/fig1-depth-split-larger-models.png`: Figure 1 used by the TeX source.
- `figures/fig2-pythia1b-training-dynamics.png`: Figure 2 used by the TeX source.
- `figures/*.pdf`: vector exports of the same figures for manual replacement if desired.

## Compile

Run from this directory:

```bash
pdflatex geometric_commitment_signatures_paper.tex
pdflatex geometric_commitment_signatures_paper.tex
```

The bibliography is inline via `thebibliography`; no separate `.bib` file is required.

The source uses common LaTeX packages: `geometry`, `graphicx`, `booktabs`, `hyperref`,
`cleveref`, `amsmath`, `amssymb`, `microtype`, `lmodern`, `xcolor`, and `listings`.
