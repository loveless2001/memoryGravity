
from typing import List
import hashlib
import numpy as np
from .config import VECTOR_DIM, SEED

class TextHasher:
    """A tiny, deterministic 'embedding' using feature hashing.
    Not semantically strong, but good enough for a demo without external deps.
    Replace with your real embedding model (e.g., OpenAI, bge-small, etc.).
    """
    def __init__(self, dim: int = VECTOR_DIM, seed: int = SEED):
        self.dim = dim
        self.seed = seed

    def _hash(self, s: str) -> int:
        h = hashlib.blake2b((str(self.seed) + s).encode('utf-8'), digest_size=8).digest()
        return int.from_bytes(h, 'little')

    def encode(self, text: str) -> np.ndarray:
        vec = np.zeros(self.dim, dtype=np.float32)
        tokens = text.lower().split()
        for tok in tokens:
            idx = self._hash(tok) % self.dim
            sign = 1 if (self._hash(tok + 'sign') % 2 == 0) else -1
            vec[idx] += sign * 1.0
        # L2 normalize
        norm = np.linalg.norm(vec) + 1e-8
        return vec / norm

    def encode_batch(self, texts: List[str]) -> np.ndarray:
        return np.stack([self.encode(t) for t in texts], axis=0)

class ImageStub:
    """Placeholder encoder for images (by path or bytes).
    Implement your CLIP/Vision embedding here later.
    For now: hash filename/bytes -> same hashing trick.
    """
    def __init__(self, dim: int = VECTOR_DIM, seed: int = SEED):
        self.dim = dim
        self.seed = seed

    def _hash(self, b: bytes) -> int:
        h = hashlib.blake2b(b + bytes([self.seed]), digest_size=8).digest()
        return int.from_bytes(h, 'little')

    def encode_path(self, path: str) -> np.ndarray:
        return self.encode_bytes(path.encode('utf-8'))

    def encode_bytes(self, data: bytes) -> np.ndarray:
        vec = np.zeros(self.dim, dtype=np.float32)
        # chunk bytes
        step = max(1, len(data)//16)
        for i in range(0, len(data), step):
            chunk = data[i:i+step]
            idx = self._hash(chunk) % self.dim
            sign = 1 if (self._hash(chunk + b'sign') % 2 == 0) else -1
            vec[idx] += sign * 1.0
        norm = np.linalg.norm(vec) + 1e-8
        return vec / norm
