
from typing import Optional, List, Tuple
from dataclasses import dataclass
import numpy as np
from .store import MemoryStore, Trace
from .glyphs import GlyphRegistry
from .embeddings import TextHasher, ImageStub
from .config import VECTOR_DIM

@dataclass
class Hologram:
    store: MemoryStore
    glyphs: GlyphRegistry
    text_encoder: TextHasher
    image_encoder: ImageStub

    @classmethod
    def init(cls):
        store = MemoryStore(vec_dim=VECTOR_DIM)
        return cls(
            store=store,
            glyphs=GlyphRegistry(store),
            text_encoder=TextHasher(dim=VECTOR_DIM),
            image_encoder=ImageStub(dim=VECTOR_DIM),
        )

    # --- Write ---
    def add_text(self, glyph_id: str, text: str, trace_id: Optional[str] = None, **meta):
        trace_id = trace_id or f"text:{abs(hash(text))%10**10}"
        vec = self.text_encoder.encode(text)
        tr = Trace(trace_id=trace_id, kind='text', content=text, vec=vec, meta=meta)
        self.glyphs.attach_trace(glyph_id, tr)
        return trace_id

    def add_image_path(self, glyph_id: str, path: str, trace_id: Optional[str] = None, **meta):
        trace_id = trace_id or f"image:{abs(hash(path))%10**10}"
        vec = self.image_encoder.encode_path(path)
        tr = Trace(trace_id=trace_id, kind='image', content=path, vec=vec, meta=meta)
        self.glyphs.attach_trace(glyph_id, tr)
        return trace_id

    # --- Read ---
    def recall_glyph(self, glyph_id: str):
        return self.glyphs.recall(glyph_id)

    def search_text(self, query: str, top_k: int = 5):
        qv = self.text_encoder.encode(query)
        return self.glyphs.search_across(qv, top_k=top_k)

    # --- Utility ---
    def summarize_hit(self, trace: Trace, score: float) -> str:
        head = trace.content if trace.kind == 'text' else f"{trace.kind}:{trace.content}"
        return f"[{trace.trace_id}] ({trace.kind}) score={score:.3f} :: {head[:80]}"
