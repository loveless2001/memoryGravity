
VECTOR_DIM = 384   # keep it small for the demo
SEED = 13         # deterministic hashing
